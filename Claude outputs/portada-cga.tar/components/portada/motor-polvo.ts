// Polvo de tatami: fondo vivo de la portada. WebGL 1 a pelo, sin librerías.
// Una nube (fbm animado) del color del acento del drop que solo se ve donde hay «máscara»:
// - la estela del ratón o del dedo, que se evapora en un par de segundos;
// - una barrida automática en S al entrar, una sola vez;
// - manchas que vagan solas por toda la portada, como una lámpara de lava.
// La máscara es un canvas 2D a 1/3 de la resolución que se sube como textura en cada fotograma.

const VERTICE = `attribute vec2 aPos;varying vec2 vUv;
void main(){vUv=aPos*.5+.5;gl_Position=vec4(aPos,0.,1.);}`;

const FRAGMENTO = `precision highp float;
uniform sampler2D uMask;uniform vec3 uTinte;uniform float uTiempo,uLado,uMax;varying vec2 vUv;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);vec2 u=f*f*(3.-2.*f);
  return mix(mix(hash(i),hash(i+vec2(1,0)),u.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x),u.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+17.1;a*=.5;}return v;}
void main(){
  float m=texture2D(uMask,vUv).a;
  if(m<.004){gl_FragColor=vec4(0.);return;}
  vec2 p=gl_FragCoord.xy/uLado*3.;float t=uTiempo*.24;
  vec2 w=vec2(fbm(p+vec2(t,-t*.6)),fbm(p+vec2(5.2,1.3)-t));
  float n=fbm(p*1.2+w*2.5+vec2(0.,t)),n2=fbm(p*2.6+w*3.-t*.5);
  vec3 oscuro=uTinte*.18,claro=mix(uTinte,vec3(.97,.96,.93),.6);
  vec3 col=mix(oscuro,uTinte*1.05,smoothstep(.3,.62,n));
  col=mix(col,claro,smoothstep(.52,.8,n2)*.95);
  col+=pow(1.-abs(n2*2.-1.),8.)*.35*uTinte;
  float a=clamp(smoothstep(.25,.62,n)*.92+.08,0.,1.);
  m=smoothstep(.06,.6,m+(fbm(vUv*9.+t)-.5)*.5*smoothstep(0.,.3,m));
  a*=m*uMax;
  gl_FragColor=vec4(col*a,a);}`;

/** Ajustes de la estela (mismos valores que el original, salvo el tinte y la opacidad máxima) */
const ESTELA = { radio: 0.2, desvanecer: 0.022, duracionBarrida: 1.6, retrasoBarrida: 500 };

type Opciones = { esperarA?: string };

export function iniciarPolvo(canvas: HTMLCanvasElement, seccion: HTMLElement, { esperarA }: Opciones): () => void {
  const gl = canvas.getContext("webgl", { premultipliedAlpha: true, alpha: true, antialias: false, depth: false, stencil: false });
  if (!gl) return () => {};

  // Estado del bucle (arriba: los oyentes y la barrida pueden llamar a activar() durante el arranque)
  let visible = true, raf = 0, antes = 0, primerFotograma = true, ultimoMovimiento = 0;
  // Con la puerta del laberinto cerrada no se pinta nada: el juego se queda con toda la potencia
  let puertaAbierta = !(esperarA && document.documentElement.classList.contains("con-puerta"));

  // ---------- Programa ----------
  const sombreador = (tipo: number, fuente: string) => {
    const s = gl.createShader(tipo)!;
    gl.shaderSource(s, fuente);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? "shader");
    return s;
  };
  const prog = gl.createProgram()!;
  gl.attachShader(prog, sombreador(gl.VERTEX_SHADER, VERTICE));
  gl.attachShader(prog, sombreador(gl.FRAGMENT_SHADER, FRAGMENTO));
  gl.bindAttribLocation(prog, 0, "aPos");
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog) ?? "programa");
  gl.useProgram(prog);
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  const u = (n: string) => gl.getUniformLocation(prog, n);
  const uTiempo = u("uTiempo"), uLado = u("uLado"), uTinte = u("uTinte"), uMax = u("uMax");
  gl.uniform1i(u("uMask"), 0);

  // Tinte: el acento del drop activo (cambia solo con el tema)
  const acento = getComputedStyle(document.documentElement).getPropertyValue("--cga-acento").trim() || "#a39c84";
  const rgb = /^#?([0-9a-f]{6})$/i.exec(acento)?.[1] ?? "a39c84";
  gl.uniform3f(uTinte, ...([0, 2, 4].map((i) => parseInt(rgb.slice(i, i + 2), 16) / 255) as [number, number, number]));

  // ---------- Máscara (canvas 2D a 1/3) ----------
  const mascara = document.createElement("canvas");
  const mctx = mascara.getContext("2d")!;
  const tex = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

  let ancho = 0, alto = 0, movil = false;
  function medir() {
    const r = seccion.getBoundingClientRect();
    ancho = r.width;
    alto = r.height;
    movil = ancho < 1024;
    // Nube blanda: no necesita resolución completa
    const escala = Math.min(devicePixelRatio, 1.5) * (movil ? 0.6 : 0.75);
    canvas.width = Math.max(1, Math.round(ancho * escala));
    canvas.height = Math.max(1, Math.round(alto * escala));
    gl!.viewport(0, 0, canvas.width, canvas.height);
    gl!.uniform1f(uLado, Math.min(canvas.width, canvas.height) * (movil ? 1.1 : 0.9));
    mascara.width = Math.max(1, Math.round(ancho / 3));
    mascara.height = Math.max(1, Math.round(alto / 3));
    activar();
  }

  // ---------- Lámpara de lava: manchas de polvo que vagan solas por toda la portada ----------
  // Cada una sigue una suma de senos con frecuencias y fases al azar (distintas en cada visita):
  // suben, bajan, se cruzan y se funden sin repetir el camino. Su tamaño respira.
  const azar = (min: number, max: number) => min + Math.random() * (max - min);
  const manchas = Array.from({ length: 6 }, (_, i) => ({
    cx: azar(0.2, 0.8),
    ax: azar(0.18, 0.32), fx: azar(0.11, 0.24), px: azar(0, 6.3),
    bx: azar(0.05, 0.12), gx: azar(0.31, 0.5),
    ay: azar(0.3, 0.42), fy: azar(0.08, 0.17), py: azar(0, 6.3),
    by: azar(0.04, 0.1), gy: azar(0.27, 0.45),
    r: azar(0.22, 0.34), fr: azar(0.2, 0.45), pr: azar(0, 6.3),
    // Las primeras, más cargadas hacia el luchador (derecha en escritorio)
    sesgo: i < 3 ? 0.18 : 0,
  }));
  function lava(fotogramas: number, segundos: number) {
    const w = mascara.width, h = mascara.height;
    const fuerza = Math.min(1, (movil ? 0.016 : 0.018) * fotogramas);
    for (const m of manchas) {
      const t = segundos;
      const centroX = movil ? m.cx : Math.min(0.9, m.cx + m.sesgo);
      const x = (centroX + m.ax * Math.sin(t * m.fx + m.px) + m.bx * Math.sin(t * m.gx + m.px * 1.7)) * w;
      const y = (0.5 + m.ay * Math.sin(t * m.fy + m.py) + m.by * Math.sin(t * m.gy + m.py * 1.3)) * h;
      const r = m.r * Math.max(w, h) * (movil ? 0.75 : 0.55) * (1 + 0.22 * Math.sin(t * m.fr + m.pr));
      const g = mctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, `rgba(255,255,255,${fuerza})`);
      g.addColorStop(0.5, `rgba(255,255,255,${fuerza * 0.55})`);
      g.addColorStop(1, "rgba(255,255,255,0)");
      mctx.fillStyle = g;
      mctx.fillRect(x - r, y - r, r * 2, r * 2);
    }
  }

  // ---------- Estela: manchas radiales a lo largo del tramo recorrido ----------
  function estampar(a: [number, number], b: [number, number], fuerza = 1) {
    const r = Math.min(mascara.width, mascara.height) * ESTELA.radio * (movil ? 1.3 : 1);
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const pasos = Math.max(1, Math.ceil(Math.hypot(dx, dy) / (r / 4)));
    for (let i = 1; i <= pasos; i++) {
      const t = i / pasos;
      const rr = r * (0.75 + Math.random() * 0.5);
      const x = a[0] + dx * t + (Math.random() - 0.5) * 0.3 * r;
      const y = a[1] + dy * t + (Math.random() - 0.5) * 0.3 * r;
      const g = mctx.createRadialGradient(x, y, 0, x, y, rr);
      g.addColorStop(0, `rgba(255,255,255,${0.5 * fuerza})`);
      g.addColorStop(0.6, `rgba(255,255,255,${0.25 * fuerza})`);
      g.addColorStop(1, "rgba(255,255,255,0)");
      mctx.fillStyle = g;
      mctx.fillRect(x - rr, y - rr, rr * 2, rr * 2);
    }
  }

  // ---------- Puntero y dedo (solo se guarda; se dibuja en el bucle) ----------
  let puntero: [number, number] | null = null;
  let ultimo: [number, number] | null = null;
  const alMover = (x: number, y: number) => {
    const r = seccion.getBoundingClientRect();
    if (y < r.top || y > r.bottom) return;
    puntero = [(x - r.left) / 3, (y - r.top) / 3];
    ultimoMovimiento = performance.now();
    activar();
  };
  const alPuntero = (e: PointerEvent) => alMover(e.clientX, e.clientY);
  const alTocar = (e: TouchEvent) => e.touches[0] && alMover(e.touches[0].clientX, e.touches[0].clientY);
  const alSoltar = () => {
    puntero = null;
    ultimo = null;
  };
  addEventListener("pointermove", alPuntero, { passive: true });
  addEventListener("touchmove", alTocar, { passive: true });
  addEventListener("touchend", alSoltar, { passive: true });
  document.documentElement.addEventListener("pointerleave", alSoltar);

  // ---------- Barrida de entrada (la S del original, por detrás del luchador) ----------
  let barrida = 0; // 0 → 1
  let barridaDesde = Infinity;
  let pinceladaBarrida: [number, number] | null = null;
  const empezarBarrida = () => {
    puertaAbierta = true;
    barridaDesde = performance.now() + ESTELA.retrasoBarrida;
    activar();
  };
  if (!puertaAbierta && esperarA) addEventListener(esperarA, empezarBarrida, { once: true });
  else empezarBarrida();

  // ---------- Bucle: solo corre si la portada se ve ----------
  function activar() {
    if (!raf && visible && puertaAbierta && !document.hidden) {
      antes = performance.now();
      raf = requestAnimationFrame(fotograma);
    }
  }
  function fotograma(ahora: number) {
    raf = 0;
    // En reposo (solo la lava moviéndose) basta con 30 fps: la mitad de trabajo para el móvil
    const enReposo = barrida >= 1 && ahora - ultimoMovimiento > 2500;
    if (enReposo && !primerFotograma && ahora - antes < 30) {
      activar();
      return;
    }
    const transcurrido = Math.min(1, (ahora - antes) / 1000);
    antes = ahora;
    const fotogramas = transcurrido * 60;
    const w = mascara.width, h = mascara.height;

    // Se evapora lo anterior
    mctx.globalCompositeOperation = "destination-out";
    mctx.fillStyle = `rgba(0,0,0,${Math.min(1, ESTELA.desvanecer * fotogramas)})`;
    mctx.fillRect(0, 0, w, h);
    mctx.globalCompositeOperation = "source-over";
    lava(fotogramas, ahora / 1000);

    if (barrida < 1 && ahora >= barridaDesde) {
      barrida = Math.min(1, barrida + Math.min(0.05, transcurrido) / ESTELA.duracionBarrida);
      const y = 0.9 - barrida * 0.8;
      const centro = movil ? 0.5 : 0.7;
      // De abajo arriba: el polvo se levanta del suelo por detrás del luchador
      const destino: [number, number] = [(centro + Math.sin(y * 9.5 + 1.2) * (movil ? 0.22 : 0.13)) * w, y * h];
      if (pinceladaBarrida) estampar(pinceladaBarrida, destino, 0.9);
      pinceladaBarrida = destino;
    }
    if (puntero) {
      if (ultimo) estampar(ultimo, puntero);
      ultimo = puntero;
    }

    gl!.texImage2D(gl!.TEXTURE_2D, 0, gl!.ALPHA, gl!.ALPHA, gl!.UNSIGNED_BYTE, mascara);
    gl!.uniform1f(uTiempo, ahora / 1000);
    gl!.uniform1f(uMax, movil ? 0.9 : 0.95);
    gl!.drawArrays(gl!.TRIANGLE_STRIP, 0, 4);
    if (primerFotograma) {
      primerFotograma = false;
      canvas.dataset.lista = ""; // aparece con un fundido (CSS): nunca de golpe
    }
    activar();
  }

  const io = new IntersectionObserver(([e]) => {
    visible = e.isIntersecting;
    if (visible) activar();
  });
  io.observe(seccion);
  const ro = new ResizeObserver(medir);
  ro.observe(seccion);
  const alCambiarPestana = () => activar();
  document.addEventListener("visibilitychange", alCambiarPestana);
  const alPerderContexto = (e: Event) => {
    e.preventDefault();
    cancelAnimationFrame(raf);
    raf = 0;
    visible = false;
    delete canvas.dataset.lista;
  };
  canvas.addEventListener("webglcontextlost", alPerderContexto);
  medir();

  return () => {
    cancelAnimationFrame(raf);
    io.disconnect();
    ro.disconnect();
    removeEventListener("pointermove", alPuntero);
    removeEventListener("touchmove", alTocar);
    removeEventListener("touchend", alSoltar);
    if (esperarA) removeEventListener(esperarA, empezarBarrida);
    document.documentElement.removeEventListener("pointerleave", alSoltar);
    document.removeEventListener("visibilitychange", alCambiarPestana);
    canvas.removeEventListener("webglcontextlost", alPerderContexto);
    gl.getExtension("WEBGL_lose_context")?.loseContext();
  };
}
