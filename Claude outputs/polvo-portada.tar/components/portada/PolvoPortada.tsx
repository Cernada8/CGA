"use client";

import { useEffect, useRef } from "react";
import { EVENTO_PUERTA_ABIERTA } from "@/lib/puerta";
import { CONSULTAS } from "@/lib/motion";

/**
 * Fondo de la portada: polvo de tatami que se levanta al pasar el ratón o el dedo y se posa solo.
 * El motor (WebGL, unos pocos KB) se descarga cuando el navegador está libre: no toca el LCP ni el JS inicial.
 * Con movimiento reducido o sin WebGL no se pinta nada: queda el negro con grano de siempre.
 */
export function PolvoPortada() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    const seccion = canvas?.parentElement;
    if (!canvas || !seccion || matchMedia(CONSULTAS.reducido).matches) return;
    let parar: (() => void) | undefined;
    let cancelado = false;
    const arrancar = () =>
      import("./motor-polvo").then(({ iniciarPolvo }) => {
        if (cancelado) return;
        try {
          parar = iniciarPolvo(canvas, seccion, { esperarA: EVENTO_PUERTA_ABIERTA });
        } catch {
          // Sin WebGL o con el sombreador rechazado: la portada se queda como estaba
        }
      });
    const id = "requestIdleCallback" in window ? requestIdleCallback(arrancar, { timeout: 1500 }) : setTimeout(arrancar, 300);
    return () => {
      cancelado = true;
      if ("cancelIdleCallback" in window) cancelIdleCallback(id as number);
      else clearTimeout(id);
      parar?.();
    };
  }, []);
  return <canvas ref={ref} className="portada-polvo" aria-hidden="true" />;
}
